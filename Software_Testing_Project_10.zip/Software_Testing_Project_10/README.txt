Program written by : Isaac  - 200449067

Welcome to my Secure password storage program.

To compile this program (in case these .class files don't work on your machine)

Use "Software_Testing_Project_10" as your project directory

and run

-----------------------------------------------------

javac -d out -cp "lib/*" src/main/java/app/*.java

-----------------------------------------------------

to compile everything.

Once it is compiled, run

------------------------------

java -cp "out;lib/*" app.Main   

------------------------------

and the program should start.

The lib folder should have all the necessary files to ge this booted up (and more).

Click the register button to register, and read the WARNING above the master password screen.

(For testing purposes, the password field when registering and logging in is not hidden.
This is to ensure the correct password is being entered, and any login errors are not with the code)

Once you have registered, you may login and start interacting with the database.

Label means the type of account you're loggin (TWitter, facebook, etc)

Username is your username

And password is your password.

They are all hidden by defauult, but this can be toggled on and off through the checkboxes next to them.

To add a credential, fill out the form on the bottom and click the button to add them.

The generate password button next to the password field will generate a random, secure password.

To delete a credential, click the delete button next to the one you want to delete, then click confirm yes.

To exit the program, simply close it. You will be logged out.

You will onkly be able to view the credentiaals of the account you are logged into. You can make as many accounts as you would like, but they cannot share the same username.



