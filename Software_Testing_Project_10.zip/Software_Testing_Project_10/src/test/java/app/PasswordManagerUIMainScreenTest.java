package app;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.util.Collections;

import javax.swing.JCheckBox;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class PasswordManagerUIMainScreenTest {

    private PasswordManagerController controller;
    private PasswordManagerUI ui;

    @BeforeEach
    void setUp() throws Exception {
        System.setProperty("java.awt.headless", "true");
        controller = mock(PasswordManagerController.class);
        when(controller.getUsername()).thenReturn("testUser");
        when(controller.getDecryptedCredentials()).thenReturn(Collections.emptyList());
        ui = new PasswordManagerUI(controller);
    }

    @Test
    void testMainScreenComponentsAreCreated() {
        SwingUtilities.invokeLater(() -> {
            ui.showMainScreen();

            //Validates that all key components are not null
            assertNotNull(ui.labelField, "Label field should be initialized");
            assertNotNull(ui.userField, "Username field should be initialized");
            assertNotNull(ui.passField, "Password field should be initialized");
            assertNotNull(ui.addButton, "Add button should be initialized");
            assertNotNull(ui.outputArea, "Output area should be initialized");
            assertNotNull(ui.credentialTable, "Credential table should be initialized");

            //Validate table model structure
            DefaultTableModel model = (DefaultTableModel) ui.credentialTable.getModel();
            assertEquals(5, model.getColumnCount() + 1);
            assertEquals("Label", model.getColumnName(0));
        });
    }

    @Test
    void testShowPasswordCheckboxTogglesEchoChar() {
        SwingUtilities.invokeLater(() -> {
            ui.showMainScreen();

            JCheckBox showCheckBox = findCheckbox(ui.passField.getParent(), "Show");
            assertNotNull(showCheckBox, "Show checkbox should exist");

            //Initially masked
            assertNotEquals(0, ui.passField.getEchoChar());

            //Simulate checkbox action
            showCheckBox.setSelected(true);
            for (ActionListener l : showCheckBox.getActionListeners()) {
                l.actionPerformed(null);
            }

            //unmasked
            assertEquals((char) 0, ui.passField.getEchoChar());

            //Mask again
            showCheckBox.setSelected(false);
            for (ActionListener l : showCheckBox.getActionListeners()) {
                l.actionPerformed(null);
            }
            assertNotEquals(0, ui.passField.getEchoChar());
        });
    }

    //helper to find checkbox by text
    private JCheckBox findCheckbox(Container container, String text) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JCheckBox && ((JCheckBox) comp).getText().equals(text)) {
                return (JCheckBox) comp;
            }
            if (comp instanceof Container) {
                JCheckBox found = findCheckbox((Container) comp, text);
                if (found != null) return found;
            }
        }
        return null;
    }
}
