package app;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class EncryptionUtilTest {

    @Test
    public void testGenerateSaltLength() {
        byte[] salt = EncryptionUtil.generateSalt();

        assertEquals(16, salt.length, "Salt should be 16 bytes long");
    }

    @Test
    public void testHashPasswordConsistency() throws Exception {
        char[] password = "mySecurePassword".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();

        String hash1 = EncryptionUtil.hashPassword(password, salt);
        String hash2 = EncryptionUtil.hashPassword(password, salt);

        assertEquals(hash1, hash2, "Hashed passwords with same input should match");
    }

    @Test
    public void testHashPasswordUniqueness() throws Exception {
        char[] password1 = "passwordOne".toCharArray();
        char[] password2 = "passwordTwo".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();

        String hash1 = EncryptionUtil.hashPassword(password1, salt);
        String hash2 = EncryptionUtil.hashPassword(password2, salt);

        assertNotEquals(hash1, hash2, "Different passwords should yield different hashes");
    }

    @Test
    public void testKeyDerivation() throws Exception {
        char[] password = "testPassword".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();
        SecretKey key = EncryptionUtil.deriveKey(password, salt);

        assertNotNull(key, "Derived key should not be null");
        assertEquals(32, key.getEncoded().length, "Key length should be 256 bits = 32 bytes");
    }

    @Test
    public void testIVGenerationLength() {
        byte[] iv = EncryptionUtil.generateIV();
        assertEquals(16, iv.length, "IV should be 16 bytes long");
    }

    @Test
    public void testEncryptionAndDecryption() throws Exception {
        char[] password = "anotherPassword".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();
        byte[] iv = EncryptionUtil.generateIV();

        SecretKey key = EncryptionUtil.deriveKey(password, salt);
        String plaintext = "Hello, world!";

        String ciphertext = EncryptionUtil.encrypt(plaintext, key, iv);
        assertNotEquals(plaintext, ciphertext, "Ciphertext should differ from plaintext");

        String decrypted = EncryptionUtil.decrypt(ciphertext, key, iv);
        assertEquals(plaintext, decrypted, "Decrypted text should match original plaintext");
    }

    @Test
    public void testDecryptWithWrongKeyFails() throws Exception {
        char[] correctPassword = "correctPassword".toCharArray();
        char[] wrongPassword = "wrongPassword".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();
        byte[] iv = EncryptionUtil.generateIV();

        SecretKey correctKey = EncryptionUtil.deriveKey(correctPassword, salt);
        SecretKey wrongKey = EncryptionUtil.deriveKey(wrongPassword, salt);

        String plaintext = "Sensitive Data";
        String encrypted = EncryptionUtil.encrypt(plaintext, correctKey, iv);

        assertThrows(Exception.class, () -> {
            EncryptionUtil.decrypt(encrypted, wrongKey, iv);
        }, "Decryption with incorrect key should throw exception");
    }

    @Test
    public void testDecryptWithWrongIVFails() throws Exception {
        char[] password = "securePassword".toCharArray();
        byte[] salt = EncryptionUtil.generateSalt();
        byte[] correctIV = EncryptionUtil.generateIV();
        byte[] wrongIV = EncryptionUtil.generateIV();

        SecretKey key = EncryptionUtil.deriveKey(password, salt);
        String plaintext = "Hello, IV";

        String encrypted = EncryptionUtil.encrypt(plaintext, key, correctIV);

        assertThrows(Exception.class, () -> {
            EncryptionUtil.decrypt(encrypted, key, wrongIV);
        }, "Decryption with wrong IV should throw exception");
    }


     @Test
    public void testUniqueSalt(){

        byte[] salt1 = EncryptionUtil.generateSalt();
        byte[] salt2 = EncryptionUtil.generateSalt();

        assertNotEquals(salt1, salt2, "Salts should not match!");
    }

         @Test
    public void testUniqueIv(){

        byte[] Iv1 = EncryptionUtil.generateIV();
        byte[] Iv2 = EncryptionUtil.generateIV();

        assertNotEquals(Iv1, Iv2, "Salts should not match!");
    }

    //Encryption tests to make sure null entries aren't accepted
    @Test
    void encrypt_nullPlaintext_throws() {
                    

        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];

        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.encrypt(null, validKey, validIv));
    }



    @Test
    void encrypt_nullKey_throws() {
        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];

        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.encrypt("test", null, validIv));
    }

    @Test
    void encrypt_nullIv_throws() {

        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];
        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.encrypt("test", validKey, null));
    }

    //Decryption tests to make sure nulll entries aren;t accepted
    @Test
    void decrypt_nullCiphertext_throws() {
        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];

        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.decrypt(null, validKey, validIv));
    }

    @Test
    void decrypt_nullKey_throws() {
        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];

        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.decrypt("ciphertext", null, validIv));
    }

    @Test
    void decrypt_nullIv_throws() {

        SecretKey validKey = new SecretKeySpec(new byte[16], "AES");
        byte[] validIv = new byte[16];

        assertThrows(IllegalArgumentException.class, () ->
            EncryptionUtil.decrypt("ciphertext", validKey, null));
    }


}
