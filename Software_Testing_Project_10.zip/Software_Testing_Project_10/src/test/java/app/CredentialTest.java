package app;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class CredentialTest {

    // Valid test data
    private final String validLabel = "Email";
    private final String validUsername = "user@example.com";
    private final String validEncryptedPassword = "encrypted123";
    private final String validIv = "randomIV";
    private final int validId = 1;

    // Constructor null checks
    @Test
    void constructorShouldThrowIfLabelIsNull() {
        Exception ex = assertThrows(IllegalArgumentException.class, () ->
            new Credential(null, validUsername, validEncryptedPassword, validIv, validId));
        assertEquals("label cannot be null", ex.getMessage());
    }

    @Test
    void constructorShouldThrowIfUsernameIsNull() {
        Exception ex = assertThrows(IllegalArgumentException.class, () ->
            new Credential(validLabel, null, validEncryptedPassword, validIv, validId));
        assertEquals("username cannot be null", ex.getMessage());
    }

    @Test
    void constructorShouldThrowIfEncryptedPasswordIsNull() {
        Exception ex = assertThrows(IllegalArgumentException.class, () ->
            new Credential(validLabel, validUsername, null, validIv, validId));
        assertEquals("encryptedPassword cannot be null", ex.getMessage());
    }

    @Test
    void constructorShouldThrowIfIvIsNull() {
        Exception ex = assertThrows(IllegalArgumentException.class, () ->
            new Credential(validLabel, validUsername, validEncryptedPassword, null, validId));
        assertEquals("iv cannot be null", ex.getMessage());
    }

    //Getter checks: simulate what would happen if nulls were possible
    @Test
    void getLabelShouldThrowIfLabelIsNull() throws Exception {
        Credential cred = new Credential(validLabel, validUsername, validEncryptedPassword, validIv, validId);
        var field = Credential.class.getDeclaredField("label");
        field.setAccessible(true);
        field.set(cred, null);
        Exception ex = assertThrows(IllegalStateException.class, cred::getLabel);
        assertEquals("label is null", ex.getMessage());
    }

    @Test
    void getUsernameShouldThrowIfUsernameIsNull() throws Exception {
        Credential cred = new Credential(validLabel, validUsername, validEncryptedPassword, validIv, validId);
        var field = Credential.class.getDeclaredField("username");
        field.setAccessible(true);
        field.set(cred, null);
        Exception ex = assertThrows(IllegalStateException.class, cred::getUsername);
        assertEquals("username is null", ex.getMessage());
    }

    @Test
    void getEncryptedPasswordShouldThrowIfEncryptedPasswordIsNull() throws Exception {
        Credential cred = new Credential(validLabel, validUsername, validEncryptedPassword, validIv, validId);
        var field = Credential.class.getDeclaredField("encryptedPassword");
        field.setAccessible(true);
        field.set(cred, null);
        Exception ex = assertThrows(IllegalStateException.class, cred::getEncryptedPassword);
        assertEquals("encryptedPassword is null", ex.getMessage());
    }

    @Test
    void getIvShouldThrowIfIvIsNull() throws Exception {
        Credential cred = new Credential(validLabel, validUsername, validEncryptedPassword, validIv, validId);
        var field = Credential.class.getDeclaredField("iv");
        field.setAccessible(true);
        field.set(cred, null);
        Exception ex = assertThrows(IllegalStateException.class, cred::getIv);
        assertEquals("iv is null", ex.getMessage());
    }

    @Test
    void getIdShouldReturnValue() {
        Credential cred = new Credential(validLabel, validUsername, validEncryptedPassword, validIv, validId);
        assertEquals(validId, cred.getId());
    }
}
