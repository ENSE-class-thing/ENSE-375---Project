package app;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DatabaseManagerTest {

    private DatabaseManager db;

    @BeforeEach
    public void setup() {
        // Uses in-memory SQLite DB for testing, not normal constructor
        db = new DatabaseManager("jdbc:sqlite::memory:");
    }

    @Test
    public void testRegisterAndUserExists() throws SQLException {
        String user = "testuser";
        String hashedPassword = "hashedpwd";
        byte[] salt = new byte[]{1, 2, 3};

        assertFalse(db.userExists(user));
        assertTrue(db.registerUser(user, hashedPassword, salt));
        assertTrue(db.userExists(user));

        //Trying to register same username again returns false
        assertFalse(db.registerUser(user, hashedPassword, salt));
    }

    @Test
    public void testGetHashedPasswordAndSalt() throws SQLException {
        String user = "alice";
        String hashedPassword = "hash123";
        byte[] salt = new byte[]{10, 20, 30};

        db.registerUser(user, hashedPassword, salt);

        assertEquals(hashedPassword, db.getHashedPassword(user));
        assertArrayEquals(salt, db.getSalt(user));
    }

    @Test
    public void testInsertAndGetAllCredentials() throws SQLException {
        String user = "bob";
        db.registerUser(user, "pwd", new byte[]{0});

        Credential cred1 = new Credential("Email", "bob@email.com", "encpass1", "iv1", 0);
        Credential cred2 = new Credential("GitHub", "bobgit", "encpass2", "iv2", 0);

        db.insertCredential(user, cred1);
        db.insertCredential(user, cred2);

        List<Credential> creds = db.getAllCredentials(user);

        assertEquals(2, creds.size());

        //Check if the labels exist (asuming the other data is accurate as well)
        assertTrue(creds.stream().anyMatch(c -> c.getLabel().equals("Email")));
        assertTrue(creds.stream().anyMatch(c -> c.getLabel().equals("GitHub")));
    }

    @Test
    public void testDeleteCredential() throws SQLException {
        String user = "charlie";
        db.registerUser(user, "pwd", new byte[]{0});

        Credential cred = new Credential("Label1", "username1", "encpass", "iv", 0);
        db.insertCredential(user, cred);

        List<Credential> credsBefore = db.getAllCredentials(user);
        assertEquals(1, credsBefore.size());

        int idToDelete = credsBefore.get(0).getId();
        db.deleteCredential(user, idToDelete);

        List<Credential> credsAfter = db.getAllCredentials(user);
        assertEquals(0, credsAfter.size());
    }

    //This test is meant to ensure that the delete function is deleting the correct credential
    //Generates 3, deletes the second one
    //Credential 1 and 3 should still exist
    @Test
    public void testDeleteSecondCredentialAmongThree() throws SQLException {
        String user = "david";
        db.registerUser(user, "pwd", new byte[]{0});

        Credential cred1 = new Credential("Label1", "user1", "encpass1", "iv1", 0);
        Credential cred2 = new Credential("Label2", "user2", "encpass2", "iv2", 0);
        Credential cred3 = new Credential("Label3", "user3", "encpass3", "iv3", 0);

        db.insertCredential(user, cred1);
        db.insertCredential(user, cred2);
        db.insertCredential(user, cred3);

        List<Credential> credsBefore = db.getAllCredentials(user);
        assertEquals(3, credsBefore.size());

        //Find ID of the 2nd credential (Label2)
        int idToDelete = credsBefore.stream()
            .filter(c -> "Label2".equals(c.getLabel()))
            .findFirst()
            .map(Credential::getId)
            .orElseThrow(() -> new AssertionError("Credential Label2 not found"));

        //Delete the 2nd credential
        db.deleteCredential(user, idToDelete);

        //Get credentials after deletion (should only be 2)
        List<Credential> credsAfter = db.getAllCredentials(user);
        assertEquals(2, credsAfter.size());

        //Verify the remaining credentials have the correct labels (Label1 and Label3)
        assertTrue(credsAfter.stream().anyMatch(c -> "Label1".equals(c.getLabel())));
        assertTrue(credsAfter.stream().anyMatch(c -> "Label3".equals(c.getLabel())));
    }

    //Null input tests
    @Test
    void testUserExists_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.userExists(null);
        });
    }

    @Test
    void testRegisterUser_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.registerUser(null, "hashed", new byte[]{1,2,3});
        });
    }

    @Test
    void testRegisterUser_nullHashedPassword_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.registerUser("user", null, new byte[]{1,2,3});
        });
    }

    @Test
    void testRegisterUser_nullSalt_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.registerUser("user", "hashed", null);
        });
    }

    @Test
    void testGetHashedPassword_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.getHashedPassword(null);
        });
    }

    @Test
    void testGetSalt_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.getSalt(null);
        });
    }

    @Test
    void testInsertCredential_nullUsername_throws() {
        Credential cred = new Credential("label", "user", "encrypted", "iv", 0);
        assertThrows(IllegalArgumentException.class, () -> {
            db.insertCredential(null, cred);
        });
    }

    @Test
    void testInsertCredential_nullCredential_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.insertCredential("user", null);
        });
    }

    @Test
    void testDeleteCredential_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.deleteCredential(null, 1);
        });
    }

    @Test
    void testGetAllCredentials_nullUsername_throws() {
        assertThrows(IllegalArgumentException.class, () -> {
            db.getAllCredentials(null);
        });
    }

    @Test
    public void testNullUsername_throwsException() {
        Credential cred = new Credential("Email", "user@example.com", "abc123", "iv123", 0);
        Exception e = assertThrows(IllegalArgumentException.class, () ->
                db.insertCredential(null, cred));
        assertEquals("username cannot be null", e.getMessage());
    }

    @Test
    public void testNullCredential_throwsException() {
        Exception e = assertThrows(IllegalArgumentException.class, () ->
                db.insertCredential("testUser", null));
        assertEquals("credential cannot be null", e.getMessage());
    }
    

}
