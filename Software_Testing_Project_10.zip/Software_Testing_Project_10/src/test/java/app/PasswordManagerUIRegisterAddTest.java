package app;

import javax.swing.SwingUtilities;

import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PasswordManagerUIRegisterAddTest {

    private PasswordManagerController mockController;
    private PasswordManagerUI ui;

    @BeforeEach
    public void setup() {
        mockController = mock(PasswordManagerController.class);
        ui = new PasswordManagerUI(mockController);
    }


    @Test
    public void testAddCredential_withEmptyFields_doesNotCallController() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            ui.showMainScreen();

            ui.labelField.setText("");//Label field empty
            ui.userField.setText("user@example.com");
            ui.passField.setText("mySecret");

            ui.addButton.doClick();

            try {
                verify(mockController, never()).addCredential(any(), any(), any());
            } catch (Exception e) {
                fail("Unexpected exception: " + e.getMessage());
            }
        });
    }


    @Test
    public void testUserFlow_registerLoginAddCredential() throws Exception {
        when(mockController.register("testUser", "testPass", "testPass")).thenReturn(true);
        when(mockController.login("testUser", "testPass")).thenReturn(true);
        when(mockController.getUsername()).thenReturn("testUser");

        SwingUtilities.invokeAndWait(() -> {
            ui.showMainScreen();

            ui.labelField.setText("Email");
            ui.userField.setText("user@example.com");
            ui.passField.setText("mySecret123");

            ui.addButton.doClick();

            try {
                verify(mockController).addCredential("Email", "user@example.com", "mySecret123");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
