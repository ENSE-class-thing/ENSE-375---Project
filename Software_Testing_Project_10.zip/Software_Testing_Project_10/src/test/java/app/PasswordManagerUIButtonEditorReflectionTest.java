package app;

import java.awt.event.ActionEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

public class PasswordManagerUIButtonEditorReflectionTest {

    PasswordManagerController controller;
    PasswordManagerUI ui;
    JTable table;
    DefaultTableModel model;
    Object buttonEditor; //use object because class is private

    @BeforeEach
    void setup() throws Exception {
        controller = mock(PasswordManagerController.class);
        ui = spy(new PasswordManagerUI(controller));

        model = new DefaultTableModel(new Object[]{"ID", "Label", "Username", "Password", "Delete", "Selected"}, 0);
        model.addRow(new Object[]{123, "MyLabel", "MyUser", "MyPass", "Delete", true});

        table = new JTable(model);


        Class<?> buttonEditorClass = Class.forName("app.PasswordManagerUI$ButtonEditor");

        Constructor<?> ctor = buttonEditorClass.getDeclaredConstructor(
            JTable.class,
            DefaultTableModel.class,
            PasswordManagerController.class,
            PasswordManagerUI.class
        );
        ctor.setAccessible(true);

        
        buttonEditor = ctor.newInstance(table, model, controller, ui);
        Field editingRowField = buttonEditorClass.getDeclaredField("editingRow");
        editingRowField.setAccessible(true);
        editingRowField.setInt(buttonEditor, 0);




    }

    @Test
    void testActionPerformed_confirmYes_callsDelete() throws Exception {
        try (MockedStatic<JOptionPane> paneMock = mockStatic(JOptionPane.class)) {
            //simulatse user clicks YES on confirm dialog
            paneMock.when(() -> JOptionPane.showConfirmDialog(any(), anyString(), anyString(), anyInt()))
                    .thenReturn(JOptionPane.YES_OPTION);

            //spy on controller to verify deleteCredential call
            doNothing().when(controller).deleteCredential(123);

            //actionPerformed(ActionEvent)
            buttonEditor.getClass()
                    .getMethod("actionPerformed", ActionEvent.class)
                    .invoke(buttonEditor, new ActionEvent(buttonEditor, ActionEvent.ACTION_PERFORMED, ""));

            paneMock.verify(() -> JOptionPane.showConfirmDialog(any(), contains("MyLabel"), anyString(), anyInt()));

            verify(controller).deleteCredential(123);
        }
    }

    @Test
    void testActionPerformed_confirmNo_doesNotCallDelete() throws Exception {
        try (MockedStatic<JOptionPane> paneMock = mockStatic(JOptionPane.class)) {
            //simulates user clicks NO on confirm dialog
            paneMock.when(() -> JOptionPane.showConfirmDialog(any(), anyString(), anyString(), anyInt()))
                    .thenReturn(JOptionPane.NO_OPTION);

            doNothing().when(controller).deleteCredential(anyInt());

            buttonEditor.getClass()
                    .getMethod("actionPerformed", ActionEvent.class)
                    .invoke(buttonEditor, new ActionEvent(buttonEditor, ActionEvent.ACTION_PERFORMED, ""));

            paneMock.verify(() -> JOptionPane.showConfirmDialog(any(), contains("MyLabel"), anyString(), anyInt()));

            verify(controller, never()).deleteCredential(anyInt());
        }
    }
}
