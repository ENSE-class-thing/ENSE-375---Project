package app;

import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class PasswordManagerUITest {

    private PasswordManagerController controller;
    private PasswordManagerUI ui;

    @BeforeAll
    static void setUpHeadless() {
        System.setProperty("java.awt.headless", "true");
    }

    @BeforeEach
    void setUp() {
        controller = mock(PasswordManagerController.class);
        ui = new PasswordManagerUI(controller);

        //Simulates UI components
        ui.labelField = new JTextField();
        ui.userField = new JTextField();
        ui.passField = new JPasswordField();
        ui.outputArea = new JTextArea();
        ui.tableModel = new javax.swing.table.DefaultTableModel(
            new Object[]{"ID", "Label", "Username", "Password", "Delete", "Selected"}, 0
        );
        //Add button needed for tests
        ui.addButton = new JButton("Add Credential");
        //Add action listener same as in showMainScreen to test addButton behavior
        ui.addButton.addActionListener(e -> {
            String label = ui.labelField.getText().trim();
            String username = ui.userField.getText().trim();
            String password = new String(ui.passField.getPassword()).trim();

            if (label.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a label, username, and password.",
                        "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                ui.handleAddCredential(label, username, password);
            } catch (Exception ex) {
                ui.outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });
    }

    @Test
    void testHandleAddCredential_success() throws Exception {
        String label = "Email";
        String username = "john@example.com";
        String password = "mypassword";

        doNothing().when(controller).addCredential(label, username, password);
        when(controller.getDecryptedCredentials()).thenReturn(Collections.emptyList());

        ui.handleAddCredential(label, username, password);

        assertTrue(ui.outputArea.getText().contains("Added: Email"));
        assertEquals("", ui.labelField.getText());
        assertEquals("", ui.userField.getText());
        assertEquals("", new String(ui.passField.getPassword()));
        verify(controller).addCredential(label, username, password);
    }

    @Test
    void testHandleAddCredential_failure() throws Exception {
        String label = "Email";
        String username = "john@example.com";
        String password = "bad";

        doThrow(new RuntimeException("Test failure")).when(controller)
                .addCredential(label, username, password);

        Exception ex = assertThrows(Exception.class, () -> {
            ui.handleAddCredential(label, username, password);
        });

        assertEquals("Test failure", ex.getMessage());
    }

    @Test
    void testHandleDeleteCredential_success() throws Exception {
        int idToDelete = 42;

        doNothing().when(controller).deleteCredential(idToDelete);
        when(controller.getDecryptedCredentials()).thenReturn(Collections.emptyList());

        ui.handleDeleteCredential(idToDelete);

        verify(controller).deleteCredential(idToDelete);
    }

    @Test
    void testHandleDeleteCredential_throwsException() throws Exception {
        int idToDelete = 123;

        doThrow(new RuntimeException("Delete error")).when(controller)
                .deleteCredential(idToDelete);

        Exception ex = assertThrows(Exception.class, () -> {
            ui.handleDeleteCredential(idToDelete);
        });

        assertEquals("Delete error", ex.getMessage());
    }

    @Test
    void testAddButtonShowsWarningWhenFieldsEmpty() throws Exception {
        ui.labelField.setText("");
        ui.userField.setText("");
        ui.passField.setText("");

        //Mock JOptionPane to intercept message dialogue call
        try (var mockedPane = mockStatic(JOptionPane.class)) {
            ui.addButton.doClick();

            //Verify that the warning dialogue was shown
            mockedPane.verify(() -> JOptionPane.showMessageDialog(
                null,
                "Please enter a label, username, and password.",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE
            ));
        }

        //Verify addCredential was never called
        verify(controller, never()).addCredential(anyString(), anyString(), anyString());
    }

    @Test
    void testAddButtonCallsControllerOnValidInput() throws Exception {
        String label = "MyLabel";
        String username = "MyUser";
        String password = "MyPass";

        ui.labelField.setText(label);
        ui.userField.setText(username);
        ui.passField.setText(password);

        doNothing().when(controller).addCredential(label, username, password);
        when(controller.getDecryptedCredentials()).thenReturn(Collections.emptyList());

        ui.addButton.doClick();

        verify(controller, times(1)).addCredential(label, username, password);
        assertTrue(ui.outputArea.getText().contains("Added: MyLabel"));
    }


    //overrides handlers for test
    static class TestablePasswordManagerUI extends PasswordManagerUI {
        boolean loginCalled = false;
        boolean registerCalled = false;
        boolean exitCalled = false;

        TestablePasswordManagerUI(PasswordManagerController controller) {
            super(controller);
        }

        
        protected void handleLogin() {
            loginCalled = true;
        }

        
        protected void handleRegistration() {
            registerCalled = true;
        }

        @Override
        public void showLoginScreen() {
            String[] options = {"Login", "Register"};
            int choice = JOptionPane.showOptionDialog(null, "Welcome! Choose an option:", "Password Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 1) {
                handleRegistration();
            } else if (choice == 0) {
                handleLogin();
            } else {
                exitCalled = true;
            }
        }
    }

    @Test
    void testShowLoginScreen_Login() {
        try (var mocked = mockStatic(JOptionPane.class)) {
            mocked.when(() -> JOptionPane.showOptionDialog(
                    null, "Welcome! Choose an option:", "Password Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                    new Object[]{"Login", "Register"}, "Login"))
                .thenReturn(0); //login option selected

            var testUI = new TestablePasswordManagerUI(mock(PasswordManagerController.class));
            testUI.showLoginScreen();

            assertTrue(testUI.loginCalled);
            assertTrue(!testUI.registerCalled);
            assertTrue(!testUI.exitCalled);
        }
    }

    @Test
    void testShowLoginScreen_Register() {
        try (var mocked = mockStatic(JOptionPane.class)) {
            mocked.when(() -> JOptionPane.showOptionDialog(
                    null, "Welcome! Choose an option:", "Password Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                    new Object[]{"Login", "Register"}, "Login"))
                .thenReturn(1); //Register option selected

            var testUI = new TestablePasswordManagerUI(mock(PasswordManagerController.class));
            testUI.showLoginScreen();

            assertTrue(!testUI.loginCalled);
            assertTrue(testUI.registerCalled);
            assertTrue(!testUI.exitCalled);
        }
    }

    @Test
    void testShowLoginScreen_Other() {
        try (var mocked = mockStatic(JOptionPane.class)) {
            mocked.when(() -> JOptionPane.showOptionDialog(
                    null, "Welcome! Choose an option:", "Password Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                    new Object[]{"Login", "Register"}, "Login"))
                .thenReturn(-1); //Closed dialog

            var testUI = new TestablePasswordManagerUI(mock(PasswordManagerController.class));
            testUI.showLoginScreen();

            assertTrue(!testUI.loginCalled);
            assertTrue(!testUI.registerCalled);
            assertTrue(testUI.exitCalled);
        }
    }

}
