package app;

import java.lang.reflect.Method;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PasswordManagerUIReflectionTest {

    PasswordManagerController controller = mock(PasswordManagerController.class);

    //helper to invoke private method by name
    private void invokePrivateMethod(PasswordManagerUI ui, String methodName) throws Exception {
        Method method = PasswordManagerUI.class.getDeclaredMethod(methodName);
        method.setAccessible(true);
        method.invoke(ui);
    }

    //Registeration tests
    @Test
    void registration_nullUsername_callsShowLoginScreen() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:")).thenReturn(null);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleRegistration");

            verify(ui).showLoginScreen();
        }
    }

    @Test
    void registration_nullPassword_callsShowLoginScreen() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:")).thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("Enter master password:")).thenReturn(null);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleRegistration");

            verify(ui).showLoginScreen();
        }
    }

    @Test
    void registration_nullConfirmPassword_callsShowLoginScreen() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:")).thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("Enter master password:")).thenReturn("pass123");
            mockPane.when(() -> JOptionPane.showInputDialog("Re-enter master password:")).thenReturn(null);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleRegistration");

            verify(ui).showLoginScreen();
        }
    }

    @Test
    void testSuccessfulRegistration_showsSuccessDialogAndCallsShowLogin() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:")).thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("ENTER MASTER PASSWORD \n \n NOTE: YOU WILL NOT BE ABLE TO RECOVR YOUR ACCOUNT IF YOU FORGET THIS. \n No one, not even the creator of this program, will be able to recover your account if you lose this password. \n Please make sure it is something you can remember or is written down somewhere safe. \n You are recommended, but not required to do the following: \n Make the password at least 16 characters \n use lowercase letters, \n use uppercase letters, \n use numbers, \n and use special characters. \n Please enter Master Password: ")).thenReturn("pass123");
            mockPane.when(() -> JOptionPane.showInputDialog("Re-enter master password:")).thenReturn("pass123");
            mockPane.when(() -> JOptionPane.showMessageDialog(any(), any())).thenAnswer(inv -> null);

            when(controller.register("john", "pass123", "pass123")).thenReturn(true);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleRegistration");

            verify(controller).register("john", "pass123", "pass123");
            mockPane.verify(() -> JOptionPane.showMessageDialog(null, "Registration successful! Please login."));
            verify(ui).showLoginScreen();
        }
    }

    @Test
    void testFailedRegistration_showsErrorDialogAndCallsShowLogin() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:")).thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("ENTER MASTER PASSWORD \n \n NOTE: YOU WILL NOT BE ABLE TO RECOVR YOUR ACCOUNT IF YOU FORGET THIS. \n No one, not even the creator of this program, will be able to recover your account if you lose this password. \n Please make sure it is something you can remember or is written down somewhere safe. \n You are recommended, but not required to do the following: \n Make the password at least 16 characters \n use lowercase letters, \n use uppercase letters, \n use numbers, \n and use special characters. \n Please enter Master Password: ")).thenReturn("pass123");
            mockPane.when(() -> JOptionPane.showInputDialog("Re-enter master password:")).thenReturn("pass123");
            mockPane.when(() -> JOptionPane.showMessageDialog(any(), any())).thenAnswer(inv -> null);

            when(controller.register("john", "pass123", "pass123")).thenReturn(false);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleRegistration");

            verify(controller).register("john", "pass123", "pass123");
            mockPane.verify(() -> JOptionPane.showMessageDialog(null, "Username exists or passwords do not match."));
            verify(ui).showLoginScreen();
        }
    }

    //Log-in testing
    @Test
    void login_nullUsername_callsShowLoginScreen() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter username:")).thenReturn(null);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleLogin");

            verify(ui).showLoginScreen();
        }
    }

    @Test
    void login_nullPassword_callsShowLoginScreen() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter username:")).thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("Enter master password:")).thenReturn(null);

            PasswordManagerUI ui = spy(new PasswordManagerUI(controller));
            doNothing().when(ui).showLoginScreen();

            invokePrivateMethod(ui, "handleLogin");

            verify(ui).showLoginScreen();
        }
    }
}
