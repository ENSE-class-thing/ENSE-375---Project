package app;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MasterKeyCacheTest {

    @BeforeEach
    public void clearCache() throws Exception {
        //Use reflection to reset the private static key before each test
        java.lang.reflect.Field keyField = MasterKeyCache.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(null, null);
    }


    @Test
    public void testSetKeyThrowsIfNotSet() {
        assertThrows(IllegalStateException.class, () -> {
            MasterKeyCache.setKey(null);
        });
    }


    @Test
    public void testGetKeyThrowsIfNotSet() {
        assertThrows(IllegalStateException.class, () -> {
            MasterKeyCache.getKey();
        });
    }

    @Test
    public void testSetAndGetKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128);
        SecretKey secretKey = keyGen.generateKey();

        MasterKeyCache.setKey(secretKey);
        SecretKey retrieved = MasterKeyCache.getKey();

        assertSame(secretKey, retrieved, "The retrieved key should be the same as the one set");
    }
}
