package app;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


public class PasswordManagerControllerTest {

    private DatabaseManager dbMock;
    private PasswordManagerController controller;
    private final String username = "user1";
    private final String password = "pass1";
    private byte[] salt;
    private String hashedPassword;

    @BeforeEach
    public void setup() throws Exception {
        dbMock = mock(DatabaseManager.class);
        controller = new PasswordManagerController(dbMock);

        salt = EncryptionUtil.generateSalt();
        hashedPassword = EncryptionUtil.hashPassword(password.toCharArray(), salt);

        //Mock DB calls for login
        when(dbMock.getSalt(username)).thenReturn(salt);
        when(dbMock.getHashedPassword(username)).thenReturn(hashedPassword);

        //Perform login to initialize userKey and loggedInUsername
        boolean loggedIn = controller.login(username, password);
        assertTrue(loggedIn, "Login should succeed in setup");

        //Validate userKey is initialized
        assertNotNull(controller.getUserKey(), "userKey should be initialized after login");
        assertEquals(username, controller.getUsername(), "loggedInUsername should be set after login");
    }

    @Test
    public void testRegisterSuccess() throws Exception {
        when(dbMock.registerUser(anyString(), anyString(), any())).thenReturn(true);

        boolean result = controller.register(username, password, password);
        assertTrue(result);

        verify(dbMock, times(1)).registerUser(eq(username), anyString(), any());
    }

    @Test
    public void testRegisterFailPasswordsMismatch() throws Exception {
        boolean result = controller.register(username, "pass1", "pass2");
        assertFalse(result);

        verify(dbMock, never()).registerUser(anyString(), anyString(), any());
    }

    @Test
    public void testLoginSuccess() throws Exception {
        //Test with a new controller instance
        PasswordManagerController newController = new PasswordManagerController(dbMock);

        when(dbMock.getSalt(username)).thenReturn(salt);
        when(dbMock.getHashedPassword(username)).thenReturn(hashedPassword);

        boolean result = newController.login(username, password);
        assertTrue(result);
        assertEquals(username, newController.getUsername());
        assertNotNull(newController.getUserKey());
    }

    @Test
    public void testLoginFailInvalidUser() throws Exception {
        when(dbMock.getSalt("nonexistent")).thenReturn(null);

        boolean result = controller.login("nonexistent", password);
        assertFalse(result);
    }

    @Test
    public void testLoginFailWrongPassword() throws Exception {
        byte[] anotherSalt = EncryptionUtil.generateSalt();
        String wrongHash = EncryptionUtil.hashPassword("correctPass".toCharArray(), anotherSalt);

        when(dbMock.getSalt(username)).thenReturn(anotherSalt);
        when(dbMock.getHashedPassword(username)).thenReturn(wrongHash);

        boolean result = controller.login(username, "wrongPass");
        assertFalse(result);
    }

    @Test
    public void testGeneratePassword() {
        String pwd = controller.generatePassword();
        assertNotNull(pwd);
        assertTrue(pwd.length() >= 16 && pwd.length() <= 32);

        assertTrue(pwd.chars().anyMatch(Character::isUpperCase));
        assertTrue(pwd.chars().anyMatch(Character::isLowerCase));
        assertTrue(pwd.chars().anyMatch(Character::isDigit));
        assertTrue(pwd.chars().anyMatch(c -> "!@#$%^&*()-_=+[]{}|;:,.<>?".indexOf(c) >= 0));
    }

    @Test
    public void testAddCredential() throws Exception {
        doNothing().when(dbMock).insertCredential(eq(username), any(Credential.class));

        controller.addCredential("label", "user", "password");

        verify(dbMock, times(1)).insertCredential(eq(username), any(Credential.class));
    }

    @Test
    public void testDeleteCredential() throws Exception {
        doNothing().when(dbMock).deleteCredential(username, 123);

        controller.deleteCredential(123);

        verify(dbMock, times(1)).deleteCredential(username, 123);
    }

    @Test
    public void testGetDecryptedCredentials() throws Exception {
        List<Credential> fakeCreds = new ArrayList<>();
        byte[] iv = EncryptionUtil.generateIV();
        String encodedIv = Base64.getEncoder().encodeToString(iv);
        String encryptedPassword = EncryptionUtil.encrypt("mypassword", controller.getUserKey(), iv);

        fakeCreds.add(new Credential("label1", username, encryptedPassword, encodedIv, 1));
        when(dbMock.getAllCredentials(username)).thenReturn(fakeCreds);

        List<Credential> decryptedCreds = controller.getDecryptedCredentials();

        assertEquals(1, decryptedCreds.size());
        Credential cred = decryptedCreds.get(0);
        assertEquals("label1", cred.getLabel());
        assertEquals(username, cred.getUsername());

        assertEquals("mypassword", cred.getEncryptedPassword());
    }

    //Null input etsting
    @Test
    public void testRegister_nullUsername() throws Exception {
        assertThrows(IllegalArgumentException.class, () ->
            controller.register(null, "pass", "pass")
        );
    }

    @Test
    public void testRegister_nullPassword() throws Exception {
        assertThrows(IllegalArgumentException.class, () ->
        controller.register("user", null, null)
        );

    }

    @Test
    public void testRegister_passwordMismatch() throws Exception {
        assertFalse(controller.register("user", "abc", "xyz"));
    }

    @Test
    public void testLogin_nullUsername() throws Exception {
        assertThrows(IllegalArgumentException.class, () ->
        controller.login(null, "pass")
        );
    }

    @Test
    public void testLogin_nullPassword() throws Exception {
        when(dbMock.getSalt("user")).thenReturn(new byte[16]);
        assertThrows(IllegalArgumentException.class, () ->
            controller.login("user", null)
        );
    }

    @Test
    public void testGetDecryptedCredentials_nullKey() throws Exception {
        when(dbMock.getAllCredentials(null)).thenReturn(Collections.emptyList());
        List<Credential> result = controller.getDecryptedCredentials();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testAddCredential_nullFields() {

        assertThrows(IllegalArgumentException.class, () ->
            controller.addCredential(null, "user", "pass")
        );
        assertThrows(IllegalArgumentException.class, () ->
            controller.addCredential("label", null, "pass")
        );
        assertThrows(IllegalArgumentException.class, () ->
            controller.addCredential("label", "user", null)
        );
    }

    @Test
    public void testDeleteCredential_nullUsername() throws Exception {
        PasswordManagerController freshController = new PasswordManagerController(dbMock);
        assertThrows(IllegalArgumentException.class, () -> freshController.deleteCredential(1));
    }
}
