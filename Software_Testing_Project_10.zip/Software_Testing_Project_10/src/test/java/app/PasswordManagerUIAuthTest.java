package app;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

public class PasswordManagerUIAuthTest {

    PasswordManagerController controller;

    //This prevents and endless loop when a user is kicked back to the login screen ater failing an attempt
    static class TestablePasswordManagerUI extends PasswordManagerUI {
        public TestablePasswordManagerUI(PasswordManagerController controller) {
            super(controller);
        }

        @Override
        public void showLoginScreen() {
            //PREVENTS RECURSIVE LOOP (DO NOT REMOVE THIS OR THE STACK OVERFLOW IS GONNA HAPPEN AGIN)
        }

        @Override
        public void showMainScreen() {
            //Overridden as well for same purpose
        }
    }

    @BeforeEach
    void setup() {
        controller = mock(PasswordManagerController.class);
    }

    @Test
    void testSuccessfulRegistration() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:"))
                    .thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("ENTER MASTER PASSWORD \n \n NOTE: YOU WILL NOT BE ABLE TO RECOVR YOUR ACCOUNT IF YOU FORGET THIS. \n No one, not even the creator of this program, will be able to recover your account if you lose this password. \n Please make sure it is something you can remember or is written down somewhere safe. \n You are recommended, but not required to do the following: \n Make the password at least 16 characters \n use lowercase letters, \n use uppercase letters, \n use numbers, \n and use special characters. \n Please enter Master Password: "))
                    .thenReturn("abc123");
            mockPane.when(() -> JOptionPane.showInputDialog("Re-enter master password:"))
                    .thenReturn("abc123");

            mockPane.when(() -> JOptionPane.showMessageDialog(any(), any())).thenAnswer(inv -> null);

            when(controller.register("john", "abc123", "abc123")).thenReturn(true);

            PasswordManagerUI ui = new TestablePasswordManagerUI(controller);
            ui.showLoginScreen();
        }
    }

    @Test
    void testRegistrationUsernameTakenOrMismatch() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter new username:"))
                    .thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("ENTER MASTER PASSWORD \n \n NOTE: YOU WILL NOT BE ABLE TO RECOVR YOUR ACCOUNT IF YOU FORGET THIS. \n No one, not even the creator of this program, will be able to recover your account if you lose this password. \n Please make sure it is something you can remember or is written down somewhere safe. \n You are recommended, but not required to do the following: \n Make the password at least 16 characters \n use lowercase letters, \n use uppercase letters, \n use numbers, \n and use special characters. \n Please enter Master Password: "))
                    .thenReturn("abc123");
            mockPane.when(() -> JOptionPane.showInputDialog("Re-enter master password:"))
                    .thenReturn("xyz456");

            mockPane.when(() -> JOptionPane.showMessageDialog(any(), any())).thenAnswer(inv -> null);

            when(controller.register("john", "abc123", "xyz456")).thenReturn(false);

            PasswordManagerUI ui = new TestablePasswordManagerUI(controller);
            ui.showLoginScreen();  //Registration should fail, but no recursion
        }
    }

    @Test
    void testLoginFailure() throws Exception {
        try (MockedStatic<JOptionPane> mockPane = mockStatic(JOptionPane.class)) {
            mockPane.when(() -> JOptionPane.showInputDialog("Enter username:"))
                    .thenReturn("john");
            mockPane.when(() -> JOptionPane.showInputDialog("Enter master password:"))
                    .thenReturn("wrongpass");

            mockPane.when(() -> JOptionPane.showMessageDialog(any(), any())).thenAnswer(inv -> null);

            when(controller.login("john", "wrongpass")).thenReturn(false);

            PasswordManagerUI ui = new TestablePasswordManagerUI(controller);
            ui.showLoginScreen();  //Login fails once, no infinite loop
        }
    }

}
