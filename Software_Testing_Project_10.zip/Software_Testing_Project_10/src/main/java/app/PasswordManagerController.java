
package app;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import javax.crypto.SecretKey;

public class PasswordManagerController {
    private final DatabaseManager db;
    private SecretKey userKey;
    private String loggedInUsername;

    public SecretKey getUserKey(){
        return userKey;
    }

    public PasswordManagerController(DatabaseManager db) {
        this.db = db;
    }

    //Attempt to register new user. Return true if successful.
    public boolean register(String username, String password, String confirmPassword) throws Exception {
        if (username == null) throw new IllegalArgumentException("username cannot be null");
        if (password == null) throw new IllegalArgumentException("password cannot be null");
        if (confirmPassword == null) throw new IllegalArgumentException("confirmPassword cannot be null");
        if (!password.trim().equals(confirmPassword.trim())) return false;
        byte[] salt = EncryptionUtil.generateSalt();
        String hashedPassword = EncryptionUtil.hashPassword(password.toCharArray(), salt);
        return db.registerUser(username, hashedPassword, salt);
    }

    //Attempts to login user, returns true if successful
    public boolean login(String username, String password) throws Exception {
        if (username == null) throw new IllegalArgumentException("username cannot be null");
        if (password == null) throw new IllegalArgumentException("password cannot be null");
        byte[] salt = db.getSalt(username);
        if (salt == null) return false;

        String hashedInput = EncryptionUtil.hashPassword(password.toCharArray(), salt);
        if (!hashedInput.equals(db.getHashedPassword(username))) return false;

        this.userKey = EncryptionUtil.deriveKey(password.toCharArray(), salt);
        this.loggedInUsername = username;
        return true;
    }

    //Generates secure password fo ruser to store in database if requested
    public String generatePassword() {
        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lower = "abcdefghijklmnopqrstuvwxyz";
        String digits = "0123456789";
        String special = "!@#$%^&*()-_=+[]{}|;:,.<>?";
        String all = upper + lower + digits + special;

        StringBuilder password = new StringBuilder();
        SecureRandom secureRand = new SecureRandom();

        password.append(upper.charAt(secureRand.nextInt(upper.length())));
        password.append(lower.charAt(secureRand.nextInt(lower.length())));
        password.append(digits.charAt(secureRand.nextInt(digits.length())));
        password.append(special.charAt(secureRand.nextInt(special.length())));

        int totalLength = 16 + secureRand.nextInt(17);
        for (int i = 4; i < totalLength; i++) {
            password.append(all.charAt(secureRand.nextInt(all.length())));
        }

        List<Character> chars = new ArrayList<>();
        for (char c : password.toString().toCharArray()) chars.add(c);
        Collections.shuffle(chars, secureRand);

        StringBuilder finalPassword = new StringBuilder();
        for (char c : chars) finalPassword.append(c);

        return finalPassword.toString();
    }

    //Gets all of user's credentials and returns them decrypted
    public List<Credential> getDecryptedCredentials() throws Exception {
        List<Credential> creds = db.getAllCredentials(getUsername());
        List<Credential> decryptedCreds = new ArrayList<>();
        for (Credential c : creds) {
            String decrypted = EncryptionUtil.decrypt(
                c.getEncryptedPassword(),
                userKey,
                Base64.getDecoder().decode(c.getIv())
            );
            Credential copy = new Credential(c.getLabel(), c.getUsername(), decrypted, c.getIv(), c.getId());
            decryptedCreds.add(copy);
        }
        return decryptedCreds;
    }

    //Adds a credential to the user's list
    public void addCredential(String label, String username, String password) throws Exception {

        if (getUsername() == null) throw new IllegalArgumentException("user must be logged in");
        if (label == null) throw new IllegalArgumentException("credential label cannot be null");
        if (username == null) throw new IllegalArgumentException("credential username cannot be null");
        if (password == null) throw new IllegalArgumentException("credential password cannot be null");

        byte[] iv = EncryptionUtil.generateIV();
        String encryptedPassword = EncryptionUtil.encrypt(password, userKey, iv);
        Credential cred = new Credential(label, username, encryptedPassword, Base64.getEncoder().encodeToString(iv), -1);
        db.insertCredential(getUsername(), cred);
    }

    //Deletes a credential from the table
    public void deleteCredential(int id) throws Exception {
        if(getUsername() == null) throw new IllegalArgumentException("user cannot be null");

        db.deleteCredential(getUsername(), id);
    }

    //Gets username user has logged in with
    public String getUsername() {
        return loggedInUsername;
    }
}

