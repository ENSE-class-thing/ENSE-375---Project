package app;


public class Credential {
    private final String label;
    private final String username;
    private final String encryptedPassword;
    private final String iv;
    private final int id;




    //Credential with dummy id so that credential can be stored (function cannot know what ID database will assign)
    public Credential(String label, String username, String encryptedPassword, String iv, int id) {
        if (label == null) throw new IllegalArgumentException("label cannot be null");
        if (username == null) throw new IllegalArgumentException("username cannot be null");
        if (encryptedPassword == null) throw new IllegalArgumentException("encryptedPassword cannot be null");
        if (iv == null) throw new IllegalArgumentException("iv cannot be null");

        this.label = label;
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.iv = iv;
        this.id = id;
    }


    public String getLabel() {
        if (label == null) throw new IllegalStateException("label is null");
        return label;
    }

    public String getUsername() {
        if (username == null) throw new IllegalStateException("username is null");
        return username;
    }

    public String getEncryptedPassword() {
        if (encryptedPassword == null) throw new IllegalStateException("encryptedPassword is null");
        return encryptedPassword;
    }

    public String getIv() {
        if (iv == null) throw new IllegalStateException("iv is null");
        return iv;
    }

    public int getId() {
        return id; //id is not checked for being null, since this is impossible due to table logic
    }
}




