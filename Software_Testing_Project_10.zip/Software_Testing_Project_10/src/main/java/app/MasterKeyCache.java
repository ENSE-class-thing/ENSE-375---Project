package app;

//One getter and one setter

import javax.crypto.SecretKey;

public class MasterKeyCache {
    private static SecretKey key;

    public static void setKey(SecretKey k) {
        if (k == null) throw new IllegalStateException("Master key cannot be null!");
        key = k;
    }

    public static SecretKey getKey() {
        if (key == null) throw new IllegalStateException("Master key not set");
        return key;
    }

}

