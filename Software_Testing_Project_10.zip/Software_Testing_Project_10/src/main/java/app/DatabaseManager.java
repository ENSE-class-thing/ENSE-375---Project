package app;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private final Connection conn;

    public DatabaseManager() {
        try {
            //Load SQLite JDBC driver (NEED THIS)
            Class.forName("org.sqlite.JDBC");

            conn = DriverManager.getConnection("jdbc:sqlite:passwords.db");
            createUsersTable();
        } catch (Exception e) {
            throw new RuntimeException("Database connection error", e);
        }
    }

    //A constructor used to test the database in the test cases, in order to not mess with the real database
    public DatabaseManager(String jdbcUrl) {
    try {
        Class.forName("org.sqlite.JDBC");
        conn = DriverManager.getConnection(jdbcUrl);
        createUsersTable();
    } catch (Exception e) {
        throw new RuntimeException("Database connection error", e);
    }
    }


    //Create the users table to hold usernames, hashed master passwords, and salts
    private void createUsersTable() throws SQLException {
        String sql = """
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                hashed_password TEXT NOT NULL,
                salt BLOB NOT NULL
            );
        """;
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        }
    }

    //Registers user to database
    public boolean registerUser(String username, String hashedPassword, byte[] salt) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");
        if (hashedPassword == null) throw new IllegalArgumentException("hashedPassword cannot be null");
        if (salt == null) throw new IllegalArgumentException("salt cannot be null");

        if (userExists(username)) {
            return false; //User already exists
        }
        String sql = "INSERT INTO users (username, hashed_password, salt) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, hashedPassword);
            pstmt.setBytes(3, salt);
            pstmt.executeUpdate();
        }
        //Creates new table for the new user
        createUserCredentialsTable(username);
        return true;
    }

    //Checks if username is already in use
    public boolean userExists(String username) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sql = "SELECT 1 FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    //Gets the hashed password associated with the username
    public String getHashedPassword(String username) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sql = "SELECT hashed_password FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("hashed_password");
                }
                return null;
            }
        }
    }

    //Gets the salt associated with the username
    public byte[] getSalt(String username) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sql = "SELECT salt FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBytes("salt");
                }
                return null;
            }
        }
    }

    //Create a "Credentials" table to be associated with a specific username
    //Each user has their credentials stored in a different table
    private void createUserCredentialsTable(String username) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sanitizedUsername = username.replaceAll("[^a-zA-Z0-9_]", "");
        String sql = String.format("""
            CREATE TABLE IF NOT EXISTS credentials_%s (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                username TEXT NOT NULL,
                encrypted_password TEXT NOT NULL,
                iv TEXT NOT NULL
            );
        """, sanitizedUsername);
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        }
    }

    //Inserts a new credential into the user's credentiaal table
    public void insertCredential(String username, Credential credential) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");
        if (credential == null) throw new IllegalArgumentException("credential cannot be null");
        //Credential elements  (label, username, etc) are not checked for being null here because the constructor doesnt allow them to be null.

        String sanitizedUsername = username.replaceAll("[^a-zA-Z0-9_]", "");
        String sql = String.format("INSERT INTO credentials_%s(label, username, encrypted_password, iv) VALUES (?, ?, ?, ?)", sanitizedUsername);

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, credential.getLabel());
            pstmt.setString(2, credential.getUsername());
            pstmt.setString(3, credential.getEncryptedPassword());
            pstmt.setString(4, credential.getIv());
            pstmt.executeUpdate();
        }
    }

    //Deletes credential from credential table
    public void deleteCredential(String username, int id) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sanitizedUsername = username.replaceAll("[^a-zA-Z0-9_]", "");
        String sql = String.format("DELETE FROM credentials_%s WHERE id = ?", sanitizedUsername);

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    //Gets all the credentials associated with a user
    public List<Credential> getAllCredentials(String username) throws SQLException {
        if (username == null) throw new IllegalArgumentException("username cannot be null");

        String sanitizedUsername = username.replaceAll("[^a-zA-Z0-9_]", "");
        String sql = String.format("SELECT id, label, username, encrypted_password, iv FROM credentials_%s", sanitizedUsername);

        List<Credential> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Credential(
                    rs.getString("label"),
                    rs.getString("username"),
                    rs.getString("encrypted_password"),
                    rs.getString("iv"),
                    rs.getInt("id")
                ));
            }
        }
        return list;
    }


    


}

