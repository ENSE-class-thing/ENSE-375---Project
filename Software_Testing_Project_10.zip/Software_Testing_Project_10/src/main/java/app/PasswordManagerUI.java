package app;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventObject;
import java.util.List;

import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public class PasswordManagerUI {

    private final PasswordManagerController controller;
    JTextField labelField;
    JTextField userField;
    JPasswordField passField;
    JButton addButton;
    JTable credentialTable;
    DefaultTableModel tableModel;
    JTextArea outputArea;

    public PasswordManagerUI(PasswordManagerController controller) {
        this.controller = controller;
    }


    //Displays login screen (first thing user sees)
    public void showLoginScreen() {
        String[] options = {"Login", "Register"};
        int choice = JOptionPane.showOptionDialog(null, "Welcome! Choose an option:", "Password Manager", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                
        if (choice == 1) {
            handleRegistration();
        } else if (choice == 0) {
            handleLogin();
        } else {
            System.exit(0);
        }
    }

    //Prompst user for input to register, sends data to controller function to attempt registration if fields are not empty
    private void handleRegistration() {
        String username = JOptionPane.showInputDialog("Enter new username:");
        if (username == null || username.isEmpty()) {
            showLoginScreen();
            return;
        }

        //Explains to user the importance of not losing their master passwords, offers tips on security
        String password = JOptionPane.showInputDialog("ENTER MASTER PASSWORD \n \n NOTE: YOU WILL NOT BE ABLE TO RECOVR YOUR ACCOUNT IF YOU FORGET THIS. \n No one, not even the creator of this program, will be able to recover your account if you lose this password. \n Please make sure it is something you can remember or is written down somewhere safe. \n You are recommended, but not required to do the following: \n Make the password at least 16 characters \n use lowercase letters, \n use uppercase letters, \n use numbers, \n and use special characters. \n Please enter Master Password: ");
        if (password == null || password.isEmpty()) {
            showLoginScreen();
            return;
        }

        String confirmPassword = JOptionPane.showInputDialog("Re-enter master password:");
        if (confirmPassword == null || confirmPassword.isEmpty()) {
            showLoginScreen();
            return;
        }

        try {
            boolean success = controller.register(username, password, confirmPassword);
            if (!success) {
                JOptionPane.showMessageDialog(null, "Username exists or passwords do not match.");
            } else {
                JOptionPane.showMessageDialog(null, "Registration successful! Please login.");
            }
            showLoginScreen();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error during registration: " + e.getMessage());
            showLoginScreen();
        }
        //User is sent back to default screen after registration either succeeds or fails
    }

    //Prompts user to login with username and password
    private void handleLogin() {
        String username = JOptionPane.showInputDialog("Enter username:");
        if (username == null || username.isEmpty()) {
            showLoginScreen();
            return;
        }

        String password = JOptionPane.showInputDialog("Enter master password:");
        if (password == null || password.isEmpty()) {
            showLoginScreen();
            return;
        }

        try {
            boolean success = controller.login(username, password);
            //If login faials, user is sent back to login screen
            if (!success) {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
                showLoginScreen();
            } else {
                //If login succeeds, user is shown their information
                showMainScreen();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Login error: " + e.getMessage());
            showLoginScreen();
        }
    }

    //This part handles the UI that show sthe user their information and allows them to insert and delete portions of it
    public void showMainScreen() {
        JFrame frame = new JFrame("Password Manager - User: " + controller.getUsername());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLayout(new BorderLayout());

        String[] columnNames = {"ID", "Label", "Username", "Password", "Delete", "Selected"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4 || column == 5;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 5) return Boolean.class;
                return super.getColumnClass(columnIndex);
            }
        };

        credentialTable = new JTable(tableModel);
        credentialTable.setCellSelectionEnabled(true);
        credentialTable.getColumnModel().getColumn(3).setCellRenderer(new PasswordRenderer());

        credentialTable.removeColumn(credentialTable.getColumnModel().getColumn(0));
        credentialTable.setRowHeight(18);
        credentialTable.setFillsViewportHeight(true);

        loadCredentials();

        credentialTable.getColumn("Delete").setCellRenderer(new ButtonRenderer());
        credentialTable.getColumn("Delete").setCellEditor(new ButtonEditor(credentialTable, tableModel, controller, this));


        tableModel.addTableModelListener(e -> {
            if (e.getColumn() == 5) {
                int row = e.getFirstRow();
                tableModel.fireTableCellUpdated(row, 3);
            }
        });

        JLabel topLabel = new JLabel("Current Credentials");
        topLabel.setHorizontalAlignment(JLabel.CENTER);
        frame.add(topLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 0.8;
        centerPanel.add(new JScrollPane(credentialTable), gbc);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));

        labelField = new JTextField();
        userField = new JTextField();
        passField = new JPasswordField();

        inputPanel.add(new JLabel("Label:"));
        inputPanel.add(labelField);
        inputPanel.add(new JLabel("Username:"));
        inputPanel.add(userField);
        inputPanel.add(new JLabel("Password:"));
        

        JPanel passPanel = new JPanel(new BorderLayout());
        passPanel.add(passField, BorderLayout.CENTER);

        JButton generateButton = new JButton("Generate");
        generateButton.addActionListener(ev -> {
            String generated = controller.generatePassword();
            passField.setText(generated);
            outputArea.append("Generated secure password.\n");
        });
        passPanel.add(generateButton, BorderLayout.EAST);

        JCheckBox showPassword = new JCheckBox("Show");
        showPassword.addActionListener(e -> {
            passField.setEchoChar(showPassword.isSelected() ? (char) 0 : '●');
        });
        passPanel.add(showPassword, BorderLayout.SOUTH);

        inputPanel.add(passPanel);

        addButton = new JButton("Add Credential");
        addButton.addActionListener(e -> {
            String label = labelField.getText().trim();
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();

            if (label.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a label, username, and password.",
                        "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                handleAddCredential(label, username, password);
            } catch (Exception ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });
        inputPanel.add(new JLabel());
        inputPanel.add(addButton);

        gbc.gridy = 1;
        gbc.weighty = 0.2;
        centerPanel.add(inputPanel, gbc);

        frame.add(centerPanel, BorderLayout.CENTER);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    public void handleAddCredential(String label, String username, String password) throws Exception {
        controller.addCredential(label, username, password);
        outputArea.append("Added: " + label + "\n");
        labelField.setText("");
        userField.setText("");
        passField.setText("");
        loadCredentials();
    }

    public void handleDeleteCredential(int id) throws Exception {
        controller.deleteCredential(id);
        loadCredentials();
    }

    private void loadCredentials() {
        try {
            tableModel.setRowCount(0);
            List<Credential> creds = controller.getDecryptedCredentials();
            for (Credential c : creds) {
                tableModel.addRow(new Object[]{
                    c.getId(), c.getLabel(), c.getUsername(), c.getEncryptedPassword(), "Delete", true
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error loading credentials: " + ex.getMessage());
        }
    }

    private static class PasswordRenderer extends JTextField implements TableCellRenderer {
        public PasswordRenderer() {
            setOpaque(true);
            setEditable(false);
            setBorder(null);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            boolean isMasked = true;
            try {
                int modelRow = table.convertRowIndexToModel(row);
                Object selectedVal = table.getModel().getValueAt(modelRow, 5);
                if (selectedVal instanceof Boolean) {
                    isMasked = (Boolean) selectedVal;
                }
            } catch (Exception ignored) {
            }

            String displayText = (value != null) ? value.toString() : "";
            if (isMasked) {
                displayText = "●".repeat(displayText.length());
            }
            setText(displayText);

            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
            return this;
        }
    }

    private static class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText("Delete");
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            return this;
        }
    }

    private static class ButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
        private final JButton button;
        private final JTable table;
        private final DefaultTableModel model;
        private final PasswordManagerController controller;
        private final PasswordManagerUI ui;
        private int editingRow = -1;

        public ButtonEditor(JTable table, DefaultTableModel model, PasswordManagerController controller, PasswordManagerUI ui) {
            this.table = table;
            this.model = model;
            this.controller = controller;
            this.ui = ui;
            button = new JButton("Delete");
            button.addActionListener(this);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            editingRow = row;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return "Delete";
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (editingRow < 0) return;
            int modelRow = table.convertRowIndexToModel(editingRow);
            int id = (int) model.getValueAt(modelRow, 0);
            String label = (String) model.getValueAt(modelRow, 1);
            String username = (String) model.getValueAt(modelRow, 2);

            int confirm = JOptionPane.showConfirmDialog(null,
                    "Are you sure you want to delete the credential:\nLabel: " + label + "\nUsername: " + username + "?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    fireEditingStopped();
                    ui.handleDeleteCredential(id);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error deleting credential: " + ex.getMessage());
                }
            } else {
                fireEditingStopped();
            }
        }
        

        @Override
        public boolean isCellEditable(EventObject e) {
            return true;
        }
    }


}

