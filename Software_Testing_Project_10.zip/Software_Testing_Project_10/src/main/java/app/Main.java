package app;

//Main function, isn't tested (since all it does is initiate the program)
//Only purpose is to initialze everything and launch the GUI

public class Main {
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        PasswordManagerController controller = new PasswordManagerController(dbManager);
        PasswordManagerUI ui = new PasswordManagerUI(controller);

        ui.showLoginScreen();
    }
    
}

