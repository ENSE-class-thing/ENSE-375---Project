package app;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtil {

    public static SecretKey deriveKey(char[] password, byte[] salt) throws Exception {
        var factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        var spec = new PBEKeySpec(password, salt, 65536, 256);
        var tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }


    //Generates a unique Iv
    public static byte[] generateIV() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    //Function to encrypt passwords
    public static String encrypt(String plaintext, SecretKey key, byte[] iv) throws Exception {
        if (plaintext == null) {
            throw new IllegalArgumentException("Plaintext must not be null");
        }
        if (key == null) {
            throw new IllegalArgumentException("SecretKey must not be null");
        }
        if (iv == null) {
            throw new IllegalArgumentException("IV must not be null");
        }

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
        byte[] encrypted = cipher.doFinal(plaintext.getBytes());
        return Base64.getEncoder().encodeToString(encrypted);
    }

    //Decryption functiuon
    public static String decrypt(String ciphertext, SecretKey key, byte[] iv) throws Exception {
        if (ciphertext == null) {
            throw new IllegalArgumentException("Ciphertext must not be null");
        }
        if (key == null) {
            throw new IllegalArgumentException("SecretKey must not be null");
        }
        if (iv == null) {
            throw new IllegalArgumentException("IV must not be null");
        }

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(ciphertext));
        return new String(decrypted);
    }

    //Parameters for salt and hash
    private static final int SALT_LENGTH = 16;
    private static final int ITERATIONS = 65536;
    private static final int KEY_LENGTH = 256;

    //Generates unique salt
    public static byte[] generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        new java.security.SecureRandom().nextBytes(salt);
        return salt;
    }

    //Hashes password
    public static String hashPassword(char[] password, byte[] salt) throws Exception {
        KeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] hash = factory.generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(hash);
    }
    
}


